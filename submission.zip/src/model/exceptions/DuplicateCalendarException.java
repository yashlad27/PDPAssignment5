package model.exceptions;

public class DuplicateCalendarException extends Exception {
  public DuplicateCalendarException(String message) {
    super(message);
  }
}
