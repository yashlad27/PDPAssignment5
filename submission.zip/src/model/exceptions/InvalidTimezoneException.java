package model.exceptions;

public class InvalidTimezoneException extends Exception {
  public InvalidTimezoneException(String message) {
    super(message);
  }
}
