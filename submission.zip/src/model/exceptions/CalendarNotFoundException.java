package model.exceptions;

public class CalendarNotFoundException extends Exception {
  public CalendarNotFoundException(String message) {
    super(message);
  }
}
